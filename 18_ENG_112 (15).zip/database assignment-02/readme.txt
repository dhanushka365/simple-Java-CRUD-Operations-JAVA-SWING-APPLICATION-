The created program can be work if the java envioroment is setup correctly.

executable jar can be found below path

assignment2 -->dist-->Application.exe


created by-pasindu uduwela
index no-18/ENG/112